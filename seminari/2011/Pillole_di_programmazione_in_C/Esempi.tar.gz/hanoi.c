/*
 * hanoi.c
 * 
 *
 * Copyright (C) 2011 - Nicola Corti
 *
 * hanoi is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * hanoi is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with hanoi; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */




#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#define DISCHI 5

int a[DISCHI], b[DISCHI], c[DISCHI];

void init_tower(int a[],int b[],int c[]) {
	int i;
	int coeff;
	coeff = 1;
	for(i=0;i<DISCHI;i++)
		{
			b[i] = c[i] = 0;
			a[i] = (i+1)*coeff;
			coeff = (coeff * 10) + 1;
		}
}

void print_tower(int a[],int b[],int c[]) {
	int i;
	printf("\n\n");
	printf("_________________________________________________________________________\n");
	printf("|\tTorre a \t|\tTorre b \t|\tTorre c \t|\n");
	printf("|\t        \t|\t        \t|\t        \t|\n");
	for(i=0;i<DISCHI;i++)
	{
		printf("|\t%d\t\t|\t%d\t\t|\t%d\t\t|\n",a[i],b[i],c[i]);
	}
	printf("_________________________________________________________________________\n");
}

void move_disc(int sorg[],int dest[]) {
	int i=0,posiz,trovato=0;
	while(!trovato) {
			if (sorg[i] != 0) {
				trovato = 1; posiz = i;
			}
			i++;
	}
	i=0;
	while(i<DISCHI && dest[i] == 0) i++;
	i--;
	dest[i] = sorg[posiz];
	sorg[posiz] = 0;
}


void hanoi_manual(int n, int primo[], int secondo[], int terzo[]) {
	char k;
	if (n == 1) {
		move_disc(primo,terzo);
		print_tower(a,b,c);
		scanf("%c",&k);
	}
	else
	{
			hanoi_manual(n-1,primo,terzo,secondo);
			move_disc(primo,terzo);
			print_tower(a,b,c);
			scanf("%c",&k);
			hanoi_manual(n-1,secondo,primo,terzo);
	}
}

void hanoi_auto(int n, int primo[], int secondo[], int terzo[], int tempo) {
	if (n == 1) {
		move_disc(primo,terzo);
		print_tower(a,b,c);
		sleep(tempo);
	}
	else {
			hanoi_auto(n-1,primo,terzo,secondo,tempo);
			move_disc(primo,terzo);
			print_tower(a,b,c);
			sleep(tempo);
			hanoi_auto(n-1,secondo,primo,terzo,tempo);
	}
}

int main() {
	int n = DISCHI;
	int risp;
	char k;
	printf("Programma per la torre di Hanoi a %d dischi\n",DISCHI);
	init_tower(a,b,c);
	printf("Impostare l'avanzamento automatico (Con -1 si imposta l'avanzamento Manuale)\n");
	scanf("%d",&risp);
	print_tower(a,b,c);
	scanf("%c",&k);
	if (risp == -1) {
		scanf("%c",&k);
		hanoi_manual(n,a,b,c);
	}
	else hanoi_auto(n,a,b,c,risp);
	printf("\nLa torre è risolta in %d passi\n\n\n", (int) exp2((double)DISCHI));
	return 0;
}
