/*
 * esempio5.c
 * 
 *
 * Copyright (C) 2011 - Michael Sanelli
 *
 * esempio5 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * esempio5 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with esempio5; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */



#include <stdlib.h>
#include <stdio.h>

//Definiamo la struttura lista
struct nodo {
	//Qui memorizzeremo il valore del singolo nodo
	int valore;
	//Qui memorizzeremo l'indirizzo del prossimo elemento della lista
	struct nodo *next;
};

void stampalista(struct nodo* lista) {
	//Usiamo un puntatore temporaneo alla testa della lista per evitare errori
	struct nodo* l=lista;
	//Controllo che la lista non sia vuota
	if (lista != NULL) {
		//Scandisco la lista finche' non finisco gli elementi
		while (l != NULL) {
			//Stampo il valore del nodo
			printf("%d ",l->valore);
			//Passo all'elemento successivo
			l=l->next;
		}
		//Metto un ritorno di carrello per la leggibilita' della stampa
		printf("\n");
	}
	else {
		//Qui siamo nel caso della lista vuota
		printf("La lista è vuota\n");
	}
}

struct nodo* instesta(struct nodo* lista, int nuovoval) {
	//Alloco lo spazio necessario per il nuovo nodo
	struct nodo* nuovo=malloc(sizeof(struct nodo));
	//Assegno al campo next l'indirizzo della testa della lista
	nuovo->next=lista;
	//Assegno il valore interessato al nuovo nodo
	nuovo->valore=nuovoval;
	//Ritorno il nuovo indirizzo alla testa della lista
	return nuovo;
}

struct nodo* cancella(struct nodo* lista, int cancellare) {
	//Uso 3 puntatori temporanei per gestire la cancellazione, elemento corrente, precedente e temporaneo
	struct nodo* corr=lista;
	struct nodo* prec=NULL;
	struct nodo* temp;
	//Controllo che la lista non sia vuota
	if (lista != NULL) {
		//Scandisco la lista finche non ho finito gli elementi da controllare oppure ho trovato l'elemento da cancellare
		while (corr->next != NULL && corr->valore!=cancellare) {
			//Faccio scorrere i due temporanei contemporaneamente
			prec=corr;
			corr=corr->next;
		}
		//Controllo che sono uscito dal while perchè ho trovato il valore da cancellare
		if (corr->valore==cancellare) {
			if (prec==NULL) {
				//Caso in cui è il primo elemento della lista
				prec = corr;
				corr = corr ->next;
				free(prec);
				lista = corr;
			}
			else {
				//Caso in cui siamo in un punto arbitrario della lista
				temp=corr;
				corr=corr->next;
				prec->next=corr;
				free(temp);
			}
		}
	}
	//Ritorno l'indirizzo della testa della lista eventualmente modificata
	return lista;
}

int main() {
	struct nodo* lista = NULL;
	lista = instesta(lista, 2);
	stampalista(lista);

	lista = instesta(lista, 1);
	stampalista(lista);
	lista = instesta(lista, 3);
	stampalista(lista);
	lista=cancella(lista,2);
	stampalista(lista);
	lista=cancella(lista,2);
	stampalista(lista);
	lista=cancella(lista,10);
	stampalista(lista);
	lista=cancella(lista,3);
	stampalista(lista);
	lista=cancella(lista,1);
	stampalista(lista);

	return 0;
}
