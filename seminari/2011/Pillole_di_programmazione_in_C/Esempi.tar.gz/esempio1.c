/*
 * esempio1.c
 * 
 *
 * Copyright (C) 2011 - Michael Sanelli
 *
 * esempio1 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * esempio1 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with esempio2; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */


#include <stdio.h>
#include <stdlib.h>

int main() {
	// Abbiamo bisogno di una variabile che memorizzi il numero di elementi nell'array
	int n=10;
	// Dichiarazione dell'array
	int array[n];
	// Variabile su cui iterare
	int i=0;
	// Lettura degli elementi da tastiera
	for (i=0;i<n;i++) {
		// Cosi` leggiamo elemento per elemento e lo inseriamo all'interno dell'array nella posizione indicata dalla variabile i
		scanf("%d",&array[i]);
	}

	// Scrittura a video degli elementi contenuti nell'array
	for (i=0;i<n;i++) {
		// Stampa il valore contenuto in array[i]
		printf("%d ",array[i]);
	}
	printf("\n");
	// Questo fa uscire il programma con stato 0 che per convenzione e` usato per l'esecuzione corretta del programma
	return 0;
}
