/*
 * esempio3.c
 * 
 *
 * Copyright (C) 2011 - Michael Sanelli
 *
 * esempio3 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * esempio3 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with esempio3; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */


#include <stdio.h>
#include <stdlib.h>

// Questa funzione scambia due elementi di un array
void scambia(int array[], int j, int k) {
	int temp;
	temp=array[j];
	array[j]=array[k];
	array[k]=temp;
}

//Questa e` una definizione di funzione usata per leggibilita` di codice
void ordinArray(int array[], int n) {
	int i;
	int j;
	int minimo;
	for (i=0;i<n;i++) {
		minimo=i;
		for (j=i+1;j<n;j++) {
			if (array[j] < array[minimo]) {
				minimo=j;
			}
		}
		scambia(array, minimo, i);
	}
}

int main() {
	// Abbiamo bisogno di una variabile che memorizzi il numero di elementi nell'array
	int n=10;
	// Dichiarazione dell'array
	int array[n];
	// Variabile su cui iterare
	int i=0;
	// Lettura degli elementi da tastiera
	for (i=0;i<n;i++) {
		// Cosi` leggiamo elemento per elemento e lo inseriamo all'interno dell'array nella posizione indicata dalla variabile i
		scanf("%d",&array[i]);
	}

	// Chiamiamo la funzione che ordina l'array
	ordinArray( array, n);
	// Scrittura a video degli elementi contenuti nell'array
	for (i=0;i<n;i++) {
		// Stampa il valore contenuto in array[i]
		printf("%d ",array[i]);
	}

	return 0;
}
