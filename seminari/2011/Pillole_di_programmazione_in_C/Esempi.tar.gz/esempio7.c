/*
 * esempio7.c
 * 
 *
 * Copyright (C) 2011 - Michael Sanelli
 *
 * esempio7 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * esempio7 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with esempio7; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, 
 * Boston, MA  02110-1301  USA
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
	//il tipo pid_t è un tipo particolare che rappresenta il process identifier del processo
	pid_t pid;
	printf("Provo a creare un processo figlio\n");
	//La chiamata di fork crea un nuovo processo figlio, restituisce 0 se è il figlio altrimenti restituisce il pid del processo creato
	pid = fork();
	//Controllo il valore di pid per capire se il processo in esecuzione è il figlio o il padre
	if (pid == 0) {
		printf("Sono il figlio e il mio pid è: %d\n", getpid());
	}
	else {
		printf("Sono il padre e il mio pid è: %d\n", getpid());
	}

	return 0;
}
