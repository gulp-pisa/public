import "strconv"

type currency struct {
	amount float64
	code   string
	w      chan float64
	r      chan float64
}

func Add(c currency, i float64) {
	c.w <- i
}

func Display(c *currency) string {
	return strconv.FormatFloat(<-c.r, 'f', 2, 64) + " " + c.code
}

