package main

import "os"

func main() {
	f, err := os.Create("/tmp/testme.txt")
	if err != nil {
		panic(err)
	}
	defer f.Close()

	// Do Somethin Here
	// ...
	// Something that make sense
	// ...
	// Maybe more
	// ...
	// Good enough

	// We coulde have closed the file here
	// But would be less readable
}
