import "strconv"

type Resource struct {
	data string
}

type Stack struct{
	elems []*Resource
	push, pop chan *Resource
}

func (s Stack) Loop(){
	
}

func (s Stack) Push(r chan <- *Resource){
	return s.push
}

func (s Pop)
