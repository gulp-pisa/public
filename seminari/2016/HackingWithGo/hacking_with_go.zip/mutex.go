import (
	"strconv"
	"sync"
)

type currency struct {
	sync.RWMutex
	amount float64
	code   string
}

var Balance = &currency{amount: 50.00, code: "EUR"}

func (c *currency) Add(i float64) {
	c.Lock()
	c.amount += i
	c.Unlock()
}

func (c *currency) Display() string {
	c.RLock()
	defer c.RUnlock()
	return strconv.FormatFloat(c.amount, 'f', 2, 64) + " " + c.code
}
