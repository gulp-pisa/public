//
//	Applicazione di Esempio realizzata da Nicola Corti
//	Linux Day 2012 Pisa - 27 Ottobre 2012
//	Per maggiori info: corti.nico [at] gmail.com

package com.example.linuxday2012;

import com.example.prova2.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Button MyButt = (Button)findViewById(R.id.button1);
        MyButt.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				EditText MyText = (EditText)findViewById(R.id.editText1);
				String MyName = MyText.getText().toString();
				
				Intent MyShareIntent = new Intent(android.content.Intent.ACTION_SEND);
				MyShareIntent.setType("text/plain");
				MyShareIntent.putExtra(android.content.Intent.EXTRA_TEXT, MyName + " ha creato la sua prima App Android!");
				startActivity(MyShareIntent);
			}
		});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
}
