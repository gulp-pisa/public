// -------------------------------------------------------------
// DO NOT EDIT! this file was generated automatically by gomacro
// Any change will be lost when the file is re-generated
// -------------------------------------------------------------

package main

func fib(n uint64,

) uint64 {
	if n <= 2 {
		return 1
	}
	return fib(n-1) + fib(n-2)
}
