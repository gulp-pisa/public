// -------------------------------------------------------------
// DO NOT EDIT! this file was generated automatically by gomacro
// Any change will be lost when the file is re-generated
// -------------------------------------------------------------

package main

var gaps = &[...]int{7979, 3547, 1577, 701, 301, 132, 57, 23, 10, 4, 1}
func shellsort(v []uint64,

) {
	j, n := 0, len(v)
	for _, gap := range gaps {
		for i := gap; i < n; i++ {
			temp := v[i]
			for j = i; j >= gap && v[j-gap] > temp; j -= gap {
				v[j] = v[j-gap]
			}

			v[j] = temp
		}
	}

}
