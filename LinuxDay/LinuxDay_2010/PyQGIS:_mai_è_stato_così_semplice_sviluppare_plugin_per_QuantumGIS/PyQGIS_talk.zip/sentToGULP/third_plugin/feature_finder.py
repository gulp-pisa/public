# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name			 	 : Closest Feature Finder Plugin
Description          : Seleziona la geometria piu' vicina la punto cliccato
Date                 : 22/Oct/10 
copyright            : (C) 2010 by Giuseppe Sucameli (Faunalia)
email                : sucameli@faunalia.it

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from qgis.gui import *

class ClosestFeatureFinder(QWidget):

	def __init__(self, iface):
		'''costruttore'''
		QWidget.__init__(self, iface.mainWindow())	# richiamo il costruttore della classe padre

		self.iface = iface	# salvo il riferimento alla interfaccia di QGis
		self.canvas = iface.mapCanvas()	# salvo il riferimento alla canvas

		# dopo aver impostato il seguente oggetto come mapTool corrente, 
		# quando l'utente fa click sulla canvas esso restituisce le coordinate 
		# del punto selezionato
		self.pointEmitter = QgsMapToolEmitPoint(self.canvas)

		# imposto l'azione da eseguire al click sulla canvas
		QObject.connect(self.pointEmitter, SIGNAL( "canvasClicked(const QgsPoint &, Qt::MouseButton)" ), self.canvasClicked)

	def start(self):
		self.iniziaCattura()

	def iniziaCattura(self):
		'''imposto pointEmitter come mapTool corrente'''
		self.canvas.setMapTool(self.pointEmitter)

	def terminaCattura(self):
		'''disabilito pointEmitter'''
		self.canvas.unsetMapTool(self.pointEmitter)


	def canvasClicked(self, point, button):
		'''eseguita quando l'utente fa click sulla canvas'''

		# controlla che vi sia un layer vettoriale selezionato
		layer = self.canvas.currentLayer()
		if layer == None or layer.type() != QgsMapLayer.VectorLayer:
			QMessageBox.warning( self, "Closest Feature Finder Plugin", "Nessun layer vettoriale selezionato" )
			return

		# controlla che sia un click col pulsante sinistro
		if button != Qt.LeftButton:
			return

		# mostra il cursore di attesa
		QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

		# disabilita il mapTool corrente (pointEmitter)
		self.terminaCattura()

		# crea il rettangolo da usare per la ricerca
		rect = QgsRectangle()
		rect.setXMinimum(point.x() - 0.1)
		rect.setXMaximum(point.x() + 0.1)
		rect.setYMinimum(point.y() - 0.1)
		rect.setYMaximum(point.y() + 0.1)

		# recupera le coordinate del rettangono nel CRS del layer selezionato
		rect = self.canvas.mapRenderer().mapToLayerCoordinates(layer, rect)

		# converte il rettangolo in una geometria in modo da poter usare 
		# le funzioni di distanza tra geometrie
		rect = QgsGeometry.fromRect(rect)

		# recupera tutte le geometrie nel layer
		layer.select([], self.canvas.extent(), True, False)

		minDistanza = -1	# conterrà la distanza della geometria più vicina
		featureId = None	# conterrà l'ID della geometria più vicina

		# cicla su tutte le geometrie recuperate, controlla la distanza 
		# dal rettangolo di ricerca e, se è più vicina di quella 
		# precedentemente trovata, la salva in featureId
		f = QgsFeature()
		while layer.nextFeature(f):
			geom = f.geometry()
			distanza = geom.distance(rect)
			if minDistanza < 0 or distanza < minDistanza:
				minDistanza = distanza
				featureId = f.id()

		# ripristina il cursore originale
		QApplication.restoreOverrideCursor()

		# seleziona la geometria più vicina al punto, nel caso se ne sia 
		# trovata una
		if featureId != None:
			layer.select(featureId)
		else:
			QMessageBox.warning(self, "Closest Feature Finder Plugin", QString.fromUtf8( "Non è stato possibile selezionare alcuna geometria" ) )



