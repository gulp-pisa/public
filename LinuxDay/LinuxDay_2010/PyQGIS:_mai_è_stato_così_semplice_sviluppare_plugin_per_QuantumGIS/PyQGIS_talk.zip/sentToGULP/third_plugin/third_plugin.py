# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name			 	 : Closest Feature Finder Plugin
Description          : Seleziona la geometria piu' vicina la punto cliccato
Date                 : 22/Oct/10 
copyright            : (C) 2010 by Giuseppe Sucameli (Faunalia)
email                : sucameli@faunalia.it

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt4.QtCore import *
from PyQt4.QtGui import *

import resources

class LayerLoader:

	def __init__(self, iface):
		self.iface = iface	# salviamo il riferimento all'interfaccia di QGis

	def initGui(self):	# aggiunge alla GUI di QGis i pulsanti per richiamare il plugin
		# creiamo l'azione che lancerà il plugin
		self.action = QAction( QIcon( ":selection.png" ), "Closest Feature Finder Plugin", self.iface.mainWindow() )
		QObject.connect( self.action, SIGNAL( "triggered()" ), self.run )

		# aggiunge il plugin alla toolbar
		self.iface.addToolBarIcon( self.action )
		self.iface.addPluginToMenu( "&LD Plugins", self.action )

	def unload(self):	# rimuove dalla GUI i pulsanti aggiunti dal plugin
		self.iface.removeToolBarIcon( self.action )
		self.iface.removePluginMenu( "&LD Plugins", self.action )

	def run(self):	# richiamato al click sull'azione
		from feature_finder import ClosestFeatureFinder
		wdg = ClosestFeatureFinder(self.iface)
		wdg.start()

