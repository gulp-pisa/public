# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'layerLoaderBase.ui'
#
# Created: Sat Oct 23 16:08:36 2010
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(400, 114)
        self.gridLayout = QtGui.QGridLayout(Dialog)
        self.gridLayout.setObjectName("gridLayout")
        self.label = QtGui.QLabel(Dialog)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.vectorFileEdit = QtGui.QLineEdit(Dialog)
        self.vectorFileEdit.setObjectName("vectorFileEdit")
        self.gridLayout.addWidget(self.vectorFileEdit, 0, 1, 1, 1)
        self.label_2 = QtGui.QLabel(Dialog)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)
        self.rasterFileEdit = QtGui.QLineEdit(Dialog)
        self.rasterFileEdit.setObjectName("rasterFileEdit")
        self.gridLayout.addWidget(self.rasterFileEdit, 1, 1, 1, 1)
        self.selectRasterBtn = QtGui.QPushButton(Dialog)
        self.selectRasterBtn.setObjectName("selectRasterBtn")
        self.gridLayout.addWidget(self.selectRasterBtn, 1, 2, 1, 1)
        self.buttonBox = QtGui.QDialogButtonBox(Dialog)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.gridLayout.addWidget(self.buttonBox, 2, 0, 1, 3)
        self.selectVectorBtn = QtGui.QPushButton(Dialog)
        self.selectVectorBtn.setObjectName("selectVectorBtn")
        self.gridLayout.addWidget(self.selectVectorBtn, 0, 2, 1, 1)

        self.retranslateUi(Dialog)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("accepted()"), Dialog.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL("rejected()"), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QtGui.QApplication.translate("Dialog", "Carica un file vettoriale o raster", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("Dialog", "Layer vettoriale", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("Dialog", "Layer raster", None, QtGui.QApplication.UnicodeUTF8))
        self.selectRasterBtn.setText(QtGui.QApplication.translate("Dialog", "Seleziona...", None, QtGui.QApplication.UnicodeUTF8))
        self.selectVectorBtn.setText(QtGui.QApplication.translate("Dialog", "Seleziona...", None, QtGui.QApplication.UnicodeUTF8))

