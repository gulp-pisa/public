# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name			 	 : Layer Loader Plugin
Description          : Carica un file vettoriale/raster in canvas
Date                 : 22/Oct/10 
copyright            : (C) 2010 by Giuseppe Sucameli (Faunalia)
email                : sucameli@faunalia.it

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

def name():
	return "Layer Loader Plugin (Secondo plugin al LD)"

def description():
	return "Carica un file vettoriale/raster in canvas"

def authorName():
	return "Giuseppe Sucameli (Faunalia)"

def version():
	return "0.1"

def qgisMinimumVersion():	# minima versione di QGis richiesta
	return "1.0"	# richiede almeno QGis 1.0

def classFactory(iface):	# inizializza il plugin
	from second_plugin import LayerLoader	# importiamo la classe che realizza il plugin
	return LayerLoader(iface)	# creiamo una istanza del plugin
