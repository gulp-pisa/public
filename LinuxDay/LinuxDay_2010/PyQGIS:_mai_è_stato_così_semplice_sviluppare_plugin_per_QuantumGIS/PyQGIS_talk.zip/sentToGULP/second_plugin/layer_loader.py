# -*- coding: utf-8 -*-

"""
/***************************************************************************
Name			 	 : Layer Loader Plugin
Description          : Carica un file vettoriale/raster in canvas
Date                 : 22/Oct/10 
copyright            : (C) 2010 by Giuseppe Sucameli (Faunalia)
email                : sucameli@faunalia.it

 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt4.QtCore import *
from PyQt4.QtGui import *

from qgis.core import *
from qgis.gui import *

from ui_layerLoaderBase import Ui_Dialog

class LayerLoaderDialog(QDialog, Ui_Dialog):

	def __init__(self, iface):
		'''costruttore'''

		QDialog.__init__(self, iface.mainWindow())	# inizializzo il QDialog
		self.setupUi(self)	# inizializzo la GUI come realizzata nel QtDesigner
		self.iface = iface	# salvo il riferimento alla interfaccia di QGis

		# imposto l'azione da eseguire al click sui pulsanti Seleziona
		QObject.connect(self.selectVectorBtn, SIGNAL( "clicked()" ), self.selectVectorLayer)
		QObject.connect(self.selectRasterBtn, SIGNAL( "clicked()" ), self.selectRasterLayer)

		# imposta l'azione quando viene premuto il pulsante OK
		QObject.connect(self, SIGNAL( "accepted()" ), self.loadLayers)


	def selectVectorLayer(self):
		'''permette di selezionare un file vettoriale'''

		# recupero le estensioni per i file vettoriali
		vectorsFilter = QgsProviderRegistry.instance().fileVectorFilters()

		# apro una dialog per la selezione del file
		filename = QFileDialog.getOpenFileName(self, "Seleziona un layer vettoriale", QString(), vectorsFilter)
		if filename.isEmpty():
			return

		# mostro il percorso del file selezionato
		self.vectorFileEdit.setText(filename)


	def selectRasterLayer(self):
		'''permette di selezionare un file raster'''

		# recupero le estensioni per i file raster
		rastersFilter = QString("")
		QgsRasterLayer.buildSupportedRasterFileFilter(rastersFilter)

		# apro una dialog per la selezione del file
		filename = QFileDialog.getOpenFileName(self, "Seleziona un layer raster", QString(), rastersFilter)
		if filename.isEmpty():
			return

		# mostro il percorso del file selezionato
		self.rasterFileEdit.setText(filename)


	def loadLayers(self):
		'''carica i file selezionati sulla canvas'''

		# se ho selezionato un file vettoriale, lo carico in canvas
		if not self.vectorFileEdit.text().isEmpty():
			self.iface.addVectorLayer( self.vectorFileEdit.text(), 'VectorLayer', 'ogr' )

		# se ho selezionato un file raster, lo carico in canvas
		if not self.rasterFileEdit.text().isEmpty():
			self.iface.addRasterLayer( self.rasterFileEdit.text(), 'RastersLayer' )
