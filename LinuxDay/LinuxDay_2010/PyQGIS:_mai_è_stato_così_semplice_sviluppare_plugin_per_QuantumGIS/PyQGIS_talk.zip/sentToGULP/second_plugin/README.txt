Layer Loader Plugin
Copyright (c) 2010 Giuseppe Sucameli (Faunalia) <sucameli@faunalia.it>

Licensed under the terms of GNU GPL v2 (or any layer)
http://www.gnu.org/copyleft/gpl.html

---

You can use the following repository to try this plugin:
http://www.faunalia.it/qgis/LDPisa2010/plugins.xml
