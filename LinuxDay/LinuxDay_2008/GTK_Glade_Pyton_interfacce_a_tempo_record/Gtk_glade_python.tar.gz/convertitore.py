#! /usr/bin/python

import gtk.glade

lista=[]

oggetto_glade = gtk.glade.XML('convertitore.glade')

finestra = oggetto_glade.get_widget('Finestra')
euri = oggetto_glade.get_widget('euri')
lire = oggetto_glade.get_widget('lire')
grafico = oggetto_glade.get_widget('grafico')

def cambia_lire(*args):
	nuovi_euri = lire.get_value()/1936.27
	euri.set_value(nuovi_euri)

def cambia_euro(*args):
	nuovi_euri = euri.get_value()
	lire.set_value(nuovi_euri * 1936.27)
	lista.append(nuovi_euri)
	ridisegna()

def ridisegna(*args):
    if not grafico.window:
        return
    contesto = grafico.window.cairo_create()
    contesto.scale(*grafico.window.get_size())

    contesto.set_source_rgb(1,1,1)
    contesto.rectangle(0,0,1,1)
    contesto.fill()
 
    contesto.set_line_width(.01)
    contesto.set_source_rgb(1,0,0)

    quanti = len(lista)
    massimo = max(lista)

    contesto.move_to(0,1)
    for indice in range(quanti):
        contesto.line_to(float(indice+1)/(quanti+1), 1-float(lista[indice])/massimo)
    contesto.line_to(1,1)
    contesto.stroke()


def esci(*args):
	gtk.main_quit()

finestra.show_all()

oggetto_glade.signal_autoconnect(locals())

finestra.connect('destroy', gtk.main_quit)

gtk.main()
